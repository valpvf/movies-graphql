const configuration = {
  apiUrl: process.env.REACT_APP_API_URL,
  apiToken: process.env.REACT_APP_API_TOKEN,
};

export default configuration;
